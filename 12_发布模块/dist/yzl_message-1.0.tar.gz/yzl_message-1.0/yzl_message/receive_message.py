def receive():
    return "来自10086的消息"